from flask_wtf import FlaskForm
from wtforms import StringField, PasswordField, BooleanField, SubmitField, TextAreaField
from wtforms.fields.html5 import EmailField
from wtforms.validators import DataRequired
from flask import Flask, render_template, redirect, request, make_response, jsonify, url_for
from data import db_session, users, new, sub, likes, dislikes, comments
from flask_login import LoginManager, login_required, login_user, logout_user, current_user
import news_api
import news_resources
from sqlalchemy_serializer import SerializerMixin
from flask_restful import reqparse, abort, Api, Resource


app = Flask(__name__)
api = Api(app)
app.config['SECRET_KEY'] = 'yandexlyceum_secret_key'
login_manager = LoginManager()
login_manager.init_app(app)


class LoginForm(FlaskForm):
    email = EmailField('Почта', validators=[DataRequired()])
    password = PasswordField('Пароль', validators=[DataRequired()])
    remember_me = BooleanField('Запомнить меня')
    submit = SubmitField('Войти')


class RegisterForm(FlaskForm):
    email = EmailField('Почта', validators=[DataRequired()])
    password = PasswordField('Пароль', validators=[DataRequired()])
    password_again = PasswordField('Повторите пароль', validators=[DataRequired()])
    name = StringField('Имя пользователя', validators=[DataRequired()])
    about = TextAreaField("Немного о себе")
    submit = SubmitField('Войти')


class NewsForm(FlaskForm):
    title = StringField('Заголовок', validators=[DataRequired()])
    content = TextAreaField("Содержание")
    is_private = BooleanField("Личное")
    submit = SubmitField('Применить')


class CommentForm(FlaskForm):
    content = TextAreaField("Содержание")
    submit = SubmitField('Применить')


@app.route("/")
def index():
    session = db_session.create_session()
    if current_user.is_authenticated:
        news = session.query(new.News).filter(
            (new.News.user == current_user) | (new.News.is_private != True))
    else:
        news = session.query(new.News).filter(new.News.is_private != True)
    shw = True
    return render_template("index.html", news=news, sub=sub, session=session, shw=shw, 
                           len=len)
@app.route('/login', methods=['GET', 'POST'])
def login():
    form = LoginForm()
    if form.validate_on_submit():
        session = db_session.create_session()
        user = session.query(users.User).filter(users.User.email == form.email.data).first()
        if user and user.check_password(form.password.data):
            login_user(user, remember=form.remember_me.data)
            return redirect("/")
        return render_template('login.html',
                               message="Неправильный логин или пароль", form=form)
    return render_template('login.html', title='Авторизация', form=form)
@app.route('/register', methods=['GET', 'POST'])
def register():
    form = RegisterForm()
    if form.validate_on_submit():
        if form.password.data != form.password_again.data:
            return render_template('register.html', title='Регистрация',
                                   form=form, message="Пароли не совпадают")
        session = db_session.create_session()
        if session.query(users.User).filter(users.User.email == form.email.data).first():
            return render_template('register.html', title='Регистрация',
                                   form=form, message="Такой пользователь уже есть")
        user = users.User(name=form.name.data, email=form.email.data, about=form.about.data, has_subs=False)
        user.set_password(form.password.data)
        session.add(user)
        session.commit()
        return redirect('/login')
    return render_template('register.html', title='Регистрация', form=form)
@login_manager.user_loader
def load_user(user_id):
    session = db_session.create_session()
    return session.query(users.User).get(user_id)
@app.errorhandler(404)
def not_found(error):
    return make_response(jsonify({'error': 'Not found'}), 404)
@app.route('/news',  methods=['GET', 'POST'])
@login_required
def add_news():
    form = NewsForm()
    if form.validate_on_submit():
        session = db_session.create_session()
        news = new.News()
        news.title = form.title.data
        news.content = form.content.data
        news.is_private = form.is_private.data
        current_user.news.append(news)
        session.merge(current_user)
        session.commit()
        return redirect('/')
    return render_template('news.html', title='Добавление новости', 
                           form=form)
@app.route('/news/<int:id>', methods=['GET', 'POST'])
@login_required
def edit_news(id):
    form = NewsForm()
    if request.method == "GET":
        session = db_session.create_session()
        news = session.query(new.News).filter(new.News.id == id, 
                                          new.News.user == current_user).first()
        if news:
            form.title.data = news.title
            form.content.data = news.content
            form.is_private.data = news.is_private
        else:
            abort(404)
    if form.validate_on_submit():
        session = db_session.create_session()
        news = session.query(new.News).filter(new.News.id == id, 
                                          new.News.user == current_user).first()
        if news:
            news.title = form.title.data
            news.content = form.content.data
            news.is_private = form.is_private.data
            session.commit()
            return redirect('/')
        else:
            abort(404)
    return render_template('news.html', title='Редактирование новости', form=form)
@app.route('/news_delete/<int:id>', methods=['GET', 'POST'])
@login_required
def news_delete(id):
    session = db_session.create_session()
    news = session.query(new.News).filter(new.News.id == id,
                                      new.News.user == current_user).first()
    if news:
        session.delete(news)
        session.commit()
    else:
        abort(404)
    return redirect('/')
@app.route('/subscribe/<int:id>')
@login_required
def subscribe(id):
    session = db_session.create_session()
    if len([u for u in session.query(sub.Subs).filter(sub.Subs.sbr == current_user.id, 
                                          sub.Subs.author == id)]) == 0: 
        subscriber = sub.Subs()
        subscriber.sbr = current_user.id
        subscriber.author = id        
        user_to_sub_to = session.query(users.User).filter(users.User.id == id).first()
        user_to_sub_to.subs.append(subscriber)
        user_to_sub_to.has_subs = True
    session.commit()
    return redirect('/')
@app.route('/unsubscribe/<int:id>')
@login_required
def unsubscribe(id):
    session = db_session.create_session()
    if len([u for u in session.query(sub.Subs).filter(sub.Subs.sbr == current_user.id, 
                                          sub.Subs.author == id)]) > 0:      
        user_to_unsub_from = session.query(users.User).filter(users.User.id == id).first()
        session.query(sub.Subs).filter(sub.Subs.sbr == current_user.id, 
                                       sub.Subs.author == id).delete()
        if not(user_to_unsub_from.subs):
            user_to_unsub_from.has_subs = False
    session.commit()
    return redirect('/')
@app.route("/like/<int:id>")
@login_required
def like(id):
    session = db_session.create_session()
    if len([u for u in session.query(likes.Like).filter(likes.Like.news_id == id, 
                                          likes.Like.user_id == current_user.id)]) == 0:
        like = likes.Like()
        like.user_id = current_user.id
        like.news_id = id
        news_to_like = session.query(new.News).filter(new.News.id == id).first()
        news_to_like.likes.append(like)
    session.commit()
    return redirect("/")
@app.route("/remove_like/<int:id>")
@login_required
def remove_like(id):
    session = db_session.create_session()
    if len([u for u in session.query(likes.Like).filter(likes.Like.user_id == current_user.id, 
                                          likes.Like.news_id == id)]) > 0: 
        user_to_remove_from = session.query(users.User).filter(users.User.id == id).first()
        session.query(likes.Like).filter(likes.Like.user_id == current_user.id, 
                                       likes.Like.news_id == id).delete()
    session.commit()
    return redirect('/')
@app.route("/dislike/<int:id>")
@login_required
def dislike(id):
    session = db_session.create_session()
    if len([u for u in session.query(dislikes.Dislike).filter(dislikes.Dislike.news_id == id, 
                                          dislikes.Dislike.user_id == current_user.id)]) == 0:
        dislike = dislikes.Dislike()
        dislike.user_id = current_user.id
        dislike.news_id = id
        news_to_dislike = session.query(new.News).filter(new.News.id == id).first()
        news_to_dislike.dislikes.append(dislike)
    session.commit()
    return redirect("/")
@app.route("/remove_dislike/<int:id>")
@login_required
def remove_dislike(id):
    session = db_session.create_session()
    if len([u for u in session.query(dislikes.Dislike).filter(dislikes.Dislike.user_id == current_user.id, 
                                          dislikes.Dislike.news_id == id)]) > 0: 
        user_to_remove_from = session.query(users.User).filter(users.User.id == id).first()
        session.query(dislikes.Dislike).filter(dislikes.Dislike.user_id == current_user.id, 
                                       dislikes.Dislike.news_id == id).delete()
    session.commit()
    return redirect('/')
@app.route('/query/<result>')
def query(result):
    session = db_session.create_session()
    authors = session.query(users.User).filter(users.User.name.like(f"%{str(result)}%"))
    session.commit()
    session = db_session.create_session()
    if current_user.is_authenticated:
        news = session.query(new.News).filter(((new.News.user == current_user) | 
                                               (new.News.is_private != True)),
                                              (new.News.title.like(f"%{str(result)}%")) |
                                              (new.News.content.like(f"%{str(result)}%")))
    else:
        news = session.query(new.News).filter((new.News.is_private != True), 
                                              ((new.News.title.like(f"%{str(result)}%")) | 
                                              (new.News.content.like(f"%{str(result)}%"))))
    session.commit()
    shw = True
    return render_template("query.html", news=news, sub=sub, session=session, authors=authors,
                           shw=shw, len=len)
@app.route('/user/<int:id>')
def user(id):
    session = db_session.create_session()
    news = session.query(new.News).filter(new.News.user_id == id)
    session.commit()
    session = db_session.create_session()
    usr = session.query(users.User).filter(users.User.id == id).first()
    session.commit()
    shw = False
    return render_template("user.html", news=news, sub=sub, session=session, usr=usr, len=len, 
                           shw=shw)
@app.route('/comments/<int:id>')
def view_comments(id):
    session = db_session.create_session()
    news = session.query(new.News).filter(new.News.id == id)
    session.commit()
    session = db_session.create_session()
    comment = session.query(comments.Comment).filter(comments.Comment.news_id == id)
    session.commit()
    shw = False
    return render_template("commentaries.html", news=news, sub=sub, session=session, len=len, 
                           shw=shw, comment=comment, users=users, query=query)
@app.route('/add_comment/<int:id>',  methods=['GET', 'POST'])
@login_required
def add_comment(id):
    form = CommentForm()
    if form.validate_on_submit():
        session = db_session.create_session()
        comment = comments.Comment()
        comment.content = form.content.data
        comment.user_id = current_user.id
        comment.user_name = current_user.name
        comment.news_id = id
        current_news = session.query(new.News).filter(new.News.id == id).first()
        current_news.comments.append(comment)
        session.merge(current_news)
        session.commit()
        return redirect('/')
    return render_template('add_comment.html', title='Добавление комментария', 
                           form=form)
@app.route('/comment_delete/<int:id>', methods=['GET', 'POST'])
@login_required
def comment_delete(id):
    session = db_session.create_session()
    comment = session.query(comments.Comment).filter(comments.Comment.id == id,
                                      comments.Comment.user_id == current_user.id).first()
    if comment:
        session.delete(comment)
        session.commit()
    else:
        abort(404)
    return redirect(f'/comments/{id}')
@app.route('/logout')
@login_required
def logout():
    logout_user()
    return redirect("/")


def main():
    db_session.global_init("db/blogs.db") 
    app.register_blueprint(news_api.blueprint)
    api.add_resource(news_resources.NewsListResource, '/api/v2/news') 
    api.add_resource(news_resources.NewsResource, '/api/v2/news/<int:news_id>')    
    app.run()


if __name__ == '__main__':
    main()